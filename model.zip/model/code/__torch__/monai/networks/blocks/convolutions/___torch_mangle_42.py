class Convolution(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  spatial_dims : int
  in_channels : int
  out_channels : int
  is_transposed : bool
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_41.ConvTranspose3d
  adn : __torch__.monai.networks.blocks.acti_norm.___torch_mangle_4.ADN
  def forward(self: __torch__.monai.networks.blocks.convolutions.___torch_mangle_42.Convolution,
    input: Tensor) -> Tensor:
    conv = self.conv
    adn = self.adn
    input0 = (conv).forward(input, None, )
    return (adn).forward(input0, )
  def __len__(self: __torch__.monai.networks.blocks.convolutions.___torch_mangle_42.Convolution) -> int:
    return 2
