class UNet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  dimensions : int
  in_channels : int
  out_channels : int
  channels : Tuple[int, int, int, int, int]
  strides : Tuple[int, int, int, int]
  kernel_size : int
  up_kernel_size : int
  num_res_units : int
  act : str
  norm : str
  dropout : float
  bias : bool
  adn_ordering : str
  model : __torch__.torch.nn.modules.container.___torch_mangle_64.Sequential
  def forward(self: __torch__.monai.networks.nets.unet.UNet,
    x: Tensor) -> Tensor:
    model = self.model
    return (model).forward(x, )
